# The Lost Vikings (3D)
### How to run
execute this commands:
```bash
chmod a+x run
./run
```