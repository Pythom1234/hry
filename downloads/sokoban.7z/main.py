#!venv/bin/python3

import pyglet
import glob
import json

zed = pyglet.image.load('obrazky/zed.png')

bedna = pyglet.image.load('obrazky/bedna.png')

cil = pyglet.image.load('obrazky/cil.png')

hrac = pyglet.image.load('obrazky/hrac.png')

spoustec = pyglet.image.load('obrazky/spoustec.png')

batch = pyglet.graphics.Batch()

zvetseni = 2

vsechny_mapy = glob.glob('mapy/*.json')
vsechny_mapy.sort()
for i in vsechny_mapy:
    vsechny_mapy[vsechny_mapy.index(i)] = (vsechny_mapy[vsechny_mapy.index(i)])[5:-5]
while True:
    print('Mas tyto mapy:',str(vsechny_mapy)[1:-1])
    nazev_mapy = input('Kterou chces hrat? ')
    try:
        with open('mapy/'+nazev_mapy+'.json') as soubor:
            data = json.load(soubor)
            mapa = data[0]
            px = data[1][1]
            py = data[1][0]
        with open('mapy/'+nazev_mapy+'.json') as soubor:
            data = json.load(soubor)
            s_mapa = data[0]
            s_pozice = data[1]
        break
    except:
        pass


win = pyglet.window.Window(caption = 'sokoban', width = round(len(mapa[0])*zvetseni*20), height = round(len(mapa)*zvetseni*20))

klavesy = []

sprites = []


def stisk(sym, mod):
    global mapa, s_mapa, px, py
    if sym == pyglet.window.key.UP:
        klavesy.append('up')
    if sym == pyglet.window.key.DOWN:
        klavesy.append('down')
    if sym == pyglet.window.key.LEFT:
        klavesy.append('left')
    if sym == pyglet.window.key.RIGHT:
        klavesy.append('right')
    if sym == pyglet.window.key.R:
        mapa = s_mapa.copy()
        px = s_pozice[1]
        py = s_pozice[0]
        with open('mapy/'+nazev_mapy+'.json') as soubor:
            data = json.load(soubor)
            s_mapa = data[0]

def pusteni(sym, mod):
    if sym == pyglet.window.key.UP:
        klavesy.remove('up')
    if sym == pyglet.window.key.DOWN:
        klavesy.remove('down')
    if sym == pyglet.window.key.LEFT:
        klavesy.remove('left')
    if sym == pyglet.window.key.RIGHT:
        klavesy.remove('right')

class Postava:
    def pohyb(self,dt):
        global mapa, px, py
        self.x = px
        self.y = py
        if 'up' in klavesy:
            if mapa[self.y-1][self.x] == 0 or mapa[self.y-1][self.x] == 4:
                self.y -= 1
            elif mapa[self.y-1][self.x] == 2 or mapa[self.y-1][self.x] == 5:
                plus = 1
                coje = 2
                while coje == 2:
                    if mapa[self.y-plus][self.x] == 2 or mapa[self.y-plus][self.x] == 5:
                        plus += 1
                        coje = 2
                    elif mapa[self.y-plus][self.x] == 0 or mapa[self.y-plus][self.x] == 4:
                        coje = 0
                    elif mapa[self.y-plus][self.x] == 1 or mapa[self.y-plus][self.x] == 3:
                        coje = 1
                if coje == 1:
                    pass
                if coje == 0:
                    if not mapa[self.y-1][self.x] == 5:
                        mapa[self.y-1][self.x] = 0
                    else:
                        mapa[self.y-1][self.x] = 4
                    for i in range(1,plus):
                        if mapa[self.y-(i+1)][self.x] == 5:
                            mapa[self.y-(i+1)][self.x] = 4
                        if mapa[self.y-(i+1)][self.x] == 4:
                            mapa[self.y-(i+1)][self.x] = 5
                        else:
                            mapa[self.y-(i+1)][self.x] = 2
                    self.y -= 1
            elif mapa[self.y-1][self.x] == 3:
                spoustece = 0
                for i in range(len(mapa)):
                    spoustece += mapa[i].count(4)
                if spoustece == 0:
                    exit('YOU WON')
        
        if 'down' in klavesy:
            if mapa[self.y+1][self.x] == 0 or mapa[self.y+1][self.x] == 4:
                self.y += 1
            elif mapa[self.y+1][self.x] == 2 or mapa[self.y+1][self.x] == 5:
                plus = 1
                coje = 2
                while coje == 2:
                    if mapa[self.y+plus][self.x] == 2 or mapa[self.y+plus][self.x] == 5:
                        plus += 1
                        coje = 2
                    elif mapa[self.y+plus][self.x] == 0 or mapa[self.y+plus][self.x] == 4:
                        coje = 0
                    elif mapa[self.y+plus][self.x] == 1 or mapa[self.y+plus][self.x] == 3:
                        coje = 1
                if coje == 1:
                    pass
                if coje == 0:
                    if not mapa[self.y+1][self.x] == 5:
                        mapa[self.y+1][self.x] = 0
                    else:
                        mapa[self.y+1][self.x] = 4
                    for i in range(1,plus):
                        if mapa[self.y+(i+1)][self.x] == 5:
                            mapa[self.y+(i+1)][self.x] = 4
                        if mapa[self.y+(i+1)][self.x] == 4:
                            mapa[self.y+(i+1)][self.x] = 5
                        else:
                            mapa[self.y+(i+1)][self.x] = 2
                    self.y += 1
            elif mapa[self.y+1][self.x] == 3:
                spoustece = 0
                for i in range(len(mapa)):
                    spoustece += mapa[i].count(4)
                if spoustece == 0:
                    exit('YOU WON')

        if 'left' in klavesy:
            if mapa[self.y][self.x-1] == 0 or mapa[self.y][self.x-1] == 4:
                self.x -= 1
            elif mapa[self.y][self.x-1] == 2 or mapa[self.y][self.x-1] == 5:
                plus = 1
                coje = 2
                while coje == 2:
                    if mapa[self.y][self.x-plus] == 2 or mapa[self.y][self.x-plus] == 5:
                        plus += 1
                        coje = 2
                    elif mapa[self.y][self.x-plus] == 0 or mapa[self.y][self.x-plus] == 4:
                        coje = 0
                    elif mapa[self.y][self.x-plus] == 1 or mapa[self.y][self.x-plus] == 3:
                        coje = 1
                if coje == 1:
                    pass
                if coje == 0:
                    if not mapa[self.y][self.x-1] == 5:
                        mapa[self.y][self.x-1] = 0
                    else:
                        mapa[self.y][self.x-1] = 4
                    for i in range(1,plus):
                        if mapa[self.y][self.x-(i+1)] == 5:
                            mapa[self.y][self.x-(i+1)] = 4
                        if mapa[self.y][self.x-(i+1)] == 4:
                            mapa[self.y][self.x-(i+1)] = 5
                        else:
                            mapa[self.y][self.x-(i+1)] = 2
                    self.x -= 1
            elif mapa[self.y][self.x-1] == 3:
                spoustece = 0
                for i in range(len(mapa)):
                    spoustece += mapa[i].count(4)
                if spoustece == 0:
                    exit('YOU WON')

        if 'right' in klavesy:
            if mapa[self.y][self.x+1] == 0 or mapa[self.y][self.x+1] == 4:
                self.x += 1
            elif mapa[self.y][self.x+1] == 2 or mapa[self.y][self.x+1] == 5:
                plus = 1
                coje = 2
                while coje == 2:
                    if mapa[self.y][self.x+plus] == 2 or mapa[self.y][self.x+plus] == 5:
                        plus += 1
                        coje = 2
                    elif mapa[self.y][self.x+plus] == 0 or mapa[self.y][self.x+plus] == 4:
                        coje = 0
                    elif mapa[self.y][self.x+plus] == 1 or mapa[self.y][self.x+plus] == 3:
                        coje = 1
                if coje == 1:
                    pass
                if coje == 0:
                    if not mapa[self.y][self.x+1] == 5:
                        mapa[self.y][self.x+1] = 0
                    else:
                        mapa[self.y][self.x+1] = 4
                    for i in range(1,plus):
                        if mapa[self.y][self.x+(i+1)] == 5:
                            mapa[self.y][self.x+(i+1)] = 4
                        if mapa[self.y][self.x+(i+1)] == 4:
                            mapa[self.y][self.x+(i+1)] = 5
                        else:
                            mapa[self.y][self.x+(i+1)] = 2
                    self.x += 1
            elif mapa[self.y][self.x+1] == 3:
                spoustece = 0
                for i in range(len(mapa)):
                    spoustece += mapa[i].count(4)
                if spoustece == 0:
                    exit('YOU WON')
        
        
        px = self.x
        py = self.y

    def __init__(self):
        self.x = px
        self.y = py
        pyglet.clock.schedule_interval(self.pohyb,0.08)

p = Postava()

def vykr():
    global sprites
    sprites.clear()
    win.clear()
    mapa.reverse()
    for y in range(len(mapa)):
        for x in range(len(mapa[y])):
            if mapa[y][x] == 0:
                if px == x and py == len(mapa)-y-1:
                    sprites.append(pyglet.sprite.Sprite(hrac,x=x*zvetseni*20,y=y*zvetseni*20,batch=batch)) 
                    sprites[-1].scale = zvetseni
            if mapa[y][x] == 1:
                sprites.append(pyglet.sprite.Sprite(zed,x=x*zvetseni*20,y=y*zvetseni*20,batch=batch))
                sprites[-1].scale = zvetseni
            if mapa[y][x] == 2 or mapa[y][x] == 5:
                sprites.append(pyglet.sprite.Sprite(bedna,x=x*zvetseni*20,y=y*zvetseni*20,batch=batch))
                sprites[-1].scale = zvetseni
            if mapa[y][x] == 3:
                sprites.append(pyglet.sprite.Sprite(cil,x=x*zvetseni*20,y=y*zvetseni*20,batch=batch))
                sprites[-1].scale = zvetseni
            if mapa[y][x] == 4:
                sprites.append(pyglet.sprite.Sprite(spoustec,x=x*zvetseni*20,y=y*zvetseni*20,batch=batch))
                sprites[-1].scale = zvetseni
                if px == x and py == len(mapa)-y-1:
                    sprites.append(pyglet.sprite.Sprite(hrac,x=x*zvetseni*20,y=y*zvetseni*20,batch=batch))
                    sprites[-1].scale = zvetseni
    mapa.reverse()
    batch.draw()
    sprites.clear()

win.push_handlers(
on_draw = vykr,
on_key_press = stisk,
on_key_release = pusteni
)

pyglet.app.run()
