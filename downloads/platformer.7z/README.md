# Platformer
### How to run
execute this commands:
```bash
chmod a+x run
./run
```

